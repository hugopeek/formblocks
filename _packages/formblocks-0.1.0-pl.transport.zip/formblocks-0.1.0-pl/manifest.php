<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e5ab2de1ac64478438a34d7389d912c1',
      'native_key' => 'formblocks',
      'filename' => 'modNamespace/9d09e29287d7bef44ef5b3771126d62e.vehicle',
      'namespace' => 'formblocks',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e9fed4fbc172c060a5236b79f8ba0e6f',
      'native_key' => NULL,
      'filename' => 'modCategory/bbc422c7b5321990d6d1ba0e3cc171ad.vehicle',
      'namespace' => 'formblocks',
    ),
  ),
);