<?php
$modx->controller->addLexiconTopic('formblocks:default');