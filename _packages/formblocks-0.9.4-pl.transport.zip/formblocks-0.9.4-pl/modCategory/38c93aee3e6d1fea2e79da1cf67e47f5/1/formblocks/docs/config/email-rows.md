## Create chunks for email rows

For the chunk matching system in the fbSimplxWidgeteer snippet to work, you'll need to add email row chunks for every CB input field.

To do this, simply duplicate the **fbEmailRow_xx** chunk for each input type. Replace the xx with the corresponding CB field ID.
For the Email and Accept Terms fields, duplicate their variants and remove the _email and _terms suffixes.