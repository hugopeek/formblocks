<?php
$modx->lexicon->load('formblocks:default');