---------------------------------------
FormBlocks
---------------------------------------
Version: 0.7.0
Author: Hugo Peek <hugo@qaraqter.nl>
---------------------------------------

FormBlocks lets you create your own forms in MODX. It uses ContentBlocks to add the various fields you need and a slightly modified FormIt version to validate and submit the forms.