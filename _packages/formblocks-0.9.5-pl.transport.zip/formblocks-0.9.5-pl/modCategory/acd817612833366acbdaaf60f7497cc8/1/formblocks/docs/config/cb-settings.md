## Adjust layout and field settings

- Set Template ID under Availability
- Choose correct chunk for all Chunk CB’s
- Change description and preview text (optional)

### Chunk fields:

- Form - fbContentBlock
- Input (Textfield) - fbInputTextfield
- Input (Textarea) - fbInputTextarea
- Input (Email) - fbInputEmail
- Input (File) - fbInputFile
- Input (Hidden) - fbInputHidden
- Accept Terms and Conditions - fbAcceptTerms