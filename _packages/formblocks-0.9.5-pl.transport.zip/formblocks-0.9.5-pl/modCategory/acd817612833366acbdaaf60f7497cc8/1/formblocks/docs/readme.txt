---------------------------------------
FormBlocks
---------------------------------------
Version: 0.9.5
Author: Hugo Peek <hugo@qaraqter.nl>
---------------------------------------

FormBlocks lets you create your own forms in MODX. It uses ContentBlocks to add the various fields you need and FormIt to validate and submit the forms.