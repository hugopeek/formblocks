## Set FormBlocks system settings

- Set all corresponding CB field ID's
- Set ID of resource containing the forms
- Turn FormItSaveForm on (optional)